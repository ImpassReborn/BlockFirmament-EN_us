West_Prime's FullHD Font
#RU
Версия: 1.0
Версия Minecraft: 1.16.5
#EN
Version: 1.0
Minecraft version: 1.16.5
#Автор/Author
Curse: https://www.curseforge.com/members/west_prime/projects
VK: https://vk.com/westprime